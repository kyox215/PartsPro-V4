from pathlib import Path
import re
root=Path('src/components/partspro')
def edit(name, changes, imports=''):
 p=root/name;s=p.read_text()
 if imports:s=s.replace('"use client";','"use client";\n\n'+imports,1)
 for old,new in changes:
  if old not in s:raise RuntimeError((name,old[:100]))
  s=s.replace(old,new,1)
 p.write_text(s)
edit('admin-remax-center.tsx',[
 ('function Field({ children, label }: { children: React.ReactNode; label: string }) {\n  return <AdminFieldGroup label={label}>{children}</AdminFieldGroup>;','function Field({ children, label, className }: { children: React.ReactNode; label: string; className?: string }) {\n  return <AdminFieldGroup label={label} className={className}>{children}</AdminFieldGroup>;'),
 ('<Card className="border-emerald-200">','<Card className="min-w-0 border-emerald-200">'),
])
edit('admin-finance-panel.tsx',[
 ('import { AdminSearchField, AdminSearchableSelect }','import { AdminSearchField }'),
 ('<div className="overflow-x-auto">','<p className="px-3 py-2 text-xs text-slate-500 md:hidden">{locale.startsWith("zh") ? "横向滑动查看参考编号、金额与成本口径" : "Scorri per vedere riferimenti, importi e base dei costi"}</p>\n        <div className="overflow-x-auto">'),
])
edit('admin-accounts-panel.tsx',[
 ('<div className="relative min-w-0">\n                <Search className="pointer-events-none absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-slate-400"/>\n                <Input value={query} onChange={(event) => setQuery(event.target.value)} onKeyDown={(event) => {','<div className="min-w-0">\n                <AdminSearchField value={query} onValueChange={setQuery} pending={loading} clearLabel={locale.startsWith("zh") ? "清除搜索" : "Cancella ricerca"} aria-label={accountText("搜索邮箱、姓名或角色", locale)} onKeyDown={(event) => {'),
 ('className="h-8 bg-white pl-8 text-sm"','className="bg-white text-sm"'),
 ('RefreshCcw, Search, ShieldCheck','RefreshCcw, ShieldCheck'),
 ('<div className="max-h-[calc(100vh-280px)] min-h-[320px] overflow-y-auto pr-1">','<div className="max-h-[calc(100svh-280px)] min-h-0 overflow-y-auto overscroll-contain pr-1 xl:min-h-[320px]">'),
], 'import { AdminSearchField } from "./admin-ui-controls";')
edit('admin-support-panel.tsx',[
 ('<Input aria-label={locale.startsWith("zh") ? "搜索客户或会话" : "Cerca cliente o conversazione"} placeholder={locale.startsWith("zh") ? "客户、邮箱、会话标题或编号" : "Cliente, email, oggetto o ID"} value={searchInput} onChange={e => setSearchInput(e.target.value)} />','<AdminSearchField containerClassName="min-w-0 flex-1" aria-label={locale.startsWith("zh") ? "搜索客户或会话" : "Cerca cliente o conversazione"} placeholder={locale.startsWith("zh") ? "客户、邮箱、会话标题或编号" : "Cliente, email, oggetto o ID"} value={searchInput} onValueChange={setSearchInput} pending={isLoadingList} clearLabel={locale.startsWith("zh") ? "清除搜索" : "Cancella ricerca"} />'),
], 'import { AdminSearchField } from "./admin-ui-controls";')
edit('admin-pricing-panel.tsx',[
 ('<select className="mt-1 block w-full rounded border p-2" value={campaign.level} onChange={event => updateCampaign({ level: event.target.value as SignupPricingCampaign["level"] })}>{customerTiers.map(tier => <option value={tier} key={tier}>{tierLabel(tier, zh)}</option>)}</select>', '<Select value={campaign.level} disabled={locked} onValueChange={level => updateCampaign({ level: level as SignupPricingCampaign["level"] })}><SelectTrigger className="mt-1 w-full bg-white" aria-label={zh ? "赠送等级" : "Livello assegnato"}><SelectValue /></SelectTrigger><SelectContent>{customerTiers.map(tier => <SelectItem value={tier} key={tier}>{tierLabel(tier, zh)}</SelectItem>)}</SelectContent></Select>'),
], 'import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";')
p=root/'admin-permissions-panel.tsx';s=p.read_text();s=s.replace('"use client";','"use client";\n\nimport { AdminSearchField } from "./admin-ui-controls";',1)
# Replace existing icon/input search wrappers while preserving search semantics.
pattern=r'<div className="relative">\s*<Search className="[^"]*" />\s*<Input\s*value=\{(query|permissionQuery)\}\s*onChange=\{\(event\) => (setQuery|setPermissionQuery)\(event.target.value\)\}\s*className="[^"]*"\s*placeholder=\{copy\.(employeeSearchPlaceholder|matrixSearchPlaceholder)\}\s*/>\s*</div>'
s,n=re.subn(pattern,lambda m:f'<AdminSearchField value={{{m[1]}}} onValueChange={{{m[2]}}} className="bg-white" placeholder={{copy.{m[3]}}} aria-label={{copy.{m[3]}}} clearLabel={{locale.startsWith("zh") ? "清除搜索" : "Cancella ricerca"}} />',s)
assert n==4,n
s=s.replace('  Search,\n','')
s=s.replace('className="truncate text-sm font-black leading-5 text-slate-900"','className="break-words text-sm font-black leading-5 text-slate-900"')
s=s.replace('className="truncate font-mono text-[10px] font-semibold leading-4 text-slate-400"','className="break-all font-mono text-xs font-semibold leading-4 text-slate-400"')
s=s.replace('className="sticky top-0 z-10 space-y-3 rounded-lg border border-amber-300 bg-amber-50 p-3"','className="space-y-2 rounded-lg border border-amber-300 bg-amber-50 p-3 sm:sticky sm:top-0 sm:z-10"')
p.write_text(s)
p=root/'admin-inventory-panel.tsx';s=p.read_text();s=s.replace('"use client";','"use client";\n\nimport { AdminSearchField } from "./admin-ui-controls";',1)
old='''<form className="relative min-w-0" onSubmit={submitSearch}>
                <Search className="absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-slate-400" />
                <Input
                  className="h-8 bg-white pl-8 text-xs"
                  value={queryInput}
                  aria-label={text.searchPlaceholder}
                  placeholder={text.searchPlaceholder}
                  onChange={(event) => setQueryInput(event.target.value)}
                />
              </form>'''
new='''<form className="col-span-2 min-w-0 md:col-span-1" onSubmit={submitSearch}>
                <AdminSearchField className="bg-white" value={queryInput} aria-label={text.searchPlaceholder} placeholder={text.searchPlaceholder} pending={pending} clearLabel={locale.startsWith("zh") ? "清除搜索" : "Cancella ricerca"} onValueChange={setQueryInput} />
              </form>'''
assert old in s;s=s.replace(old,new,1)
s=s.replace('className="grid gap-1.5 md:grid-cols-[minmax(220px,1fr)_112px_112px_132px]"','className="grid min-w-0 grid-cols-2 gap-1.5 md:grid-cols-[minmax(220px,1fr)_112px_112px_132px]"',1)
s=s.replace('  Search,\n','')
s=s.replace('className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4"><label className="grid gap-1 text-xs"><span><input type="checkbox" checked={commonPlan.applySupplier}', 'className={cn("grid min-w-0 grid-cols-2 gap-2 lg:grid-cols-4", selectedPlanIds.length === 0 && "hidden")}><label className="grid gap-1 text-xs"><span><input type="checkbox" checked={commonPlan.applySupplier}',1)
p.write_text(s)
# Explicit scope on main panel, never global card/table restyling.
scopes={
'admin-orders-panel.tsx':('className="min-w-0 space-y-3"','className="admin-ui-panel min-w-0 space-y-3"'),
'admin-rma-panel.tsx':('className="min-w-0 space-y-4"','className="admin-ui-panel min-w-0 space-y-3 sm:space-y-4"'),
'admin-accounts-panel.tsx':('return (<section className="min-w-0 space-y-3">','return (<section className="admin-ui-panel min-w-0 space-y-3">'),
'admin-pricing-panel.tsx':('className="rounded-lg border bg-white p-3"','className="admin-ui-panel rounded-lg border bg-white p-3"'),
'admin-finance-panel.tsx':('className="flex min-w-0 flex-col gap-3 sm:gap-4"','className="admin-ui-panel flex min-w-0 flex-col gap-3 sm:gap-4"'),
'admin-inventory-panel.tsx':('className="min-w-0 space-y-3"','className="admin-ui-panel min-w-0 space-y-3"'),
'admin-overview-dashboard.tsx':('className="space-y-2.5 sm:space-y-3"','className="admin-ui-panel space-y-2.5 sm:space-y-3"'),
'admin-remax-center.tsx':('className="min-w-0 space-y-3 text-slate-950"','className="admin-ui-panel min-w-0 space-y-3 text-slate-950"'),
'admin-commerce-panel.tsx':('className="min-w-0 space-y-4"','className="admin-ui-panel min-w-0 space-y-3 sm:space-y-4"'),
'admin-marketplace-panel.tsx':('className="min-w-0 space-y-4"','className="admin-ui-panel min-w-0 space-y-3 sm:space-y-4"'),
'admin-support-panel.tsx':('className="min-w-0 space-y-1.5 sm:space-y-3"','className="admin-ui-panel min-w-0 space-y-1.5 sm:space-y-3"'),
'admin-analytics-panel.tsx':('className="min-w-0 space-y-4"','className="admin-ui-panel min-w-0 space-y-3 sm:space-y-4"'),
'admin-permissions-panel.tsx':('className="min-w-0 space-y-2 text-slate-950 sm:space-y-4"','className="admin-ui-panel min-w-0 space-y-2 text-slate-950 sm:space-y-4"'),
'admin-settings-panel.tsx':('className="min-w-0 space-y-2 text-slate-950 sm:space-y-4"','className="admin-ui-panel min-w-0 space-y-2 text-slate-950 sm:space-y-4"'),
}
for name,(old,new) in scopes.items():
 p=root/name;s=p.read_text()
 if old in s:s=s.replace(old,new,1);p.write_text(s)
 else:print('scope needs review',name)
