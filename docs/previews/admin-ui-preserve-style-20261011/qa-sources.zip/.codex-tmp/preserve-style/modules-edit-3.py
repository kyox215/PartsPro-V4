from pathlib import Path
p=Path('src/components/partspro/admin-marketplace-panel.tsx');s=p.read_text().replace('"use client";', '"use client";\n\nimport { AdminSearchableSelect } from "./admin-ui-controls";',1)
marker='      <section className="space-y-2 rounded-lg border bg-white p-3">'
nav='''      <nav aria-label={locale.startsWith("zh") ? "eBay 页内定位" : "Sezioni eBay"} className="flex min-w-0 flex-wrap gap-2 rounded-lg border border-slate-200 bg-white p-2">
        {([
          ["admin-ebay-connection", locale.startsWith("zh") ? "连接与设置" : "Account e impostazioni"],
          ["admin-ebay-policies", locale.startsWith("zh") ? "销售政策" : "Condizioni"],
          ["admin-ebay-mappings", locale.startsWith("zh") ? "类目映射" : "Categorie"],
          ["admin-ebay-listings", locale.startsWith("zh") ? "商品刊登" : "Inserzioni"],
          ["admin-ebay-jobs", locale.startsWith("zh") ? "任务队列" : "Coda"],
          ["admin-ebay-orders", locale.startsWith("zh") ? "订单回流" : "Ordini"],
        ] as const).map(([id, label]) => <Button key={id} type="button" size="sm" variant="outline" onClick={() => { const target = document.getElementById(id); target?.scrollIntoView({ block: "start" }); target?.focus({ preventScroll: true }); }}>{label}</Button>)}
      </nav>
'''
assert marker in s;s=s.replace(marker,nav+marker,1)
s=s.replace('<section className="space-y-2 rounded-lg border bg-white p-3"><h3','<section id="admin-ebay-policies" tabIndex={-1} className="scroll-mt-24 space-y-2 rounded-lg border bg-white p-3"><h3',1)
old='<select className="h-10 w-full rounded border bg-white px-2" value={draft.settings[key] ?? ""} disabled={isConfigLocked || !canManageSettings} onChange={event => updateSettings({ [key]: event.target.value })}><option value="">{locale.startsWith("zh") ? "请选择" : "Seleziona"}</option>{draft.settings[key] && !(policyOptions[kind] ?? []).some(option => option.id === draft.settings[key]) && <option value={draft.settings[key]!}>{draft.settings[key]} · {locale.startsWith("zh") ? "当前值（未读取到）" : "Valore attuale non trovato"}</option>}{(policyOptions[kind] ?? []).map(option => <option key={option.id} value={option.id}>{option.name ?? option.id}</option>)}</select>'
new='''<AdminSearchableSelect value={draft.settings[key] ?? ""} ariaLabel={label} disabled={isConfigLocked || !canManageSettings} onValueChange={value => updateSettings({ [key]: value })} placeholder={locale.startsWith("zh") ? "请选择" : "Seleziona"} searchPlaceholder={locale.startsWith("zh") ? "搜索政策" : "Cerca condizioni"} options={[
 { value: "", label: locale.startsWith("zh") ? "请选择" : "Seleziona" },
 ...(draft.settings[key] && !(policyOptions[kind] ?? []).some(option => option.id === draft.settings[key]) ? [{ value: draft.settings[key]!, label: `${draft.settings[key]} · ${locale.startsWith("zh") ? "当前值（未读取到）" : "Valore attuale non trovato"}` }] : []),
 ...(policyOptions[kind] ?? []).map(option => ({ value: option.id, label: option.name ?? option.id, description: option.id }))
 ]} />'''
assert old in s;s=s.replace(old,new,1)
s=s.replace('<section className="grid gap-4 xl:grid-cols-[0.9fr_1.1fr]">','<section id="admin-ebay-connection" tabIndex={-1} className="min-w-0 scroll-mt-24 grid gap-3 xl:grid-cols-[0.9fr_1.1fr]">',1)
# Only low-frequency numeric configuration goes into a native details; controls stay mounted.
start=s.index('              <Field label={t("加价百分比")}>')
end=s.index('\n            </div>',start)
s=s[:start]+'''            </div>
            <details className="rounded-lg border border-slate-200 bg-slate-50 p-3">
              <summary className="cursor-pointer text-sm font-semibold">{locale.startsWith("zh") ? "高级参数 · 加价、库存与成色" : "Parametri avanzati · Prezzi, stock e condizione"}</summary>
              <div className="mt-3 grid min-w-0 grid-cols-2 gap-2 xl:grid-cols-4">
'''+s[start:end]+'''\n              </div>
            </details>'''+s[end+len('\n            </div>'):]
s=s.replace('<Card className="rounded-lg bg-white">\n        <CardHeader className="border-b">\n          <CardTitle>{t("类目映射")}', '<Card id="admin-ebay-mappings" tabIndex={-1} className="min-w-0 scroll-mt-24 rounded-lg bg-white">\n        <CardHeader className="border-b">\n          <CardTitle>{t("类目映射")}',1)
s=s.replace('className="space-y-2 rounded border p-3">{([[\'localCategory\'', 'className="grid min-w-0 grid-cols-2 gap-2 rounded border p-3">{([[\'localCategory\'',1)
s=s.replace('className="block space-y-1 text-xs font-semibold">{t(label)}<Input value={mapping[key]', 'className={cn("block min-w-0 space-y-1 text-xs font-semibold", key === "localCategory" && "col-span-2")}>{t(label)}<Input value={mapping[key]',1)
s=s.replace('<DataTableCard title={t("刊登状态")}>','<DataTableCard id="admin-ebay-listings" title={t("刊登状态")}>',1)
s=s.replace('<DataTableCard title={t("失败队列")}>','<DataTableCard id="admin-ebay-jobs" title={t("失败队列")}>',1)
s=s.replace('<DataTableCard title={t("订单回流日志")}>','<DataTableCard id="admin-ebay-orders" title={t("订单回流日志")}>',1)
s=s.replace('''function DataTableCard({
  children,
  title,
}: {
  children: React.ReactNode;
  title: string;
}) {
  return (
    <Card className="rounded-lg bg-white">''','''function DataTableCard({
  children,
  title,
  id,
}: {
  children: React.ReactNode;
  title: string;
  id?: string;
}) {
  return (
    <Card id={id} tabIndex={id ? -1 : undefined} className="min-w-0 scroll-mt-24 rounded-lg bg-white">''',1)
p.write_text(s)
p=Path('src/components/partspro/admin-overview-dashboard.tsx');s=p.read_text();start=s.index('      <p className="rounded border border-slate-200 bg-white px-3 py-2 text-xs text-slate-600">');end=s.index('</p>',start)
s=s[:start]+s[start:end+4].replace('<p className=', '<details className=',1).replace('>{locale.startsWith("zh") ?', '><summary className="cursor-pointer font-semibold">{locale.startsWith("zh") ? "统计口径与数据来源" : "Base delle metriche e fonti"}</summary><p className="mt-2">{locale.startsWith("zh") ?',1).replace('</p>','</p></details>',1)+s[end+4:];p.write_text(s)
p=Path('src/components/partspro/admin-analytics-panel.tsx');s=p.read_text().replace('className="flex items-start justify-between gap-3"','className="flex min-w-0 items-start justify-between gap-2 sm:gap-3"',1).replace('"mt-2 truncate text-2xl font-black text-slate-950"','"mt-2 break-all text-xl font-black text-slate-950 sm:text-2xl"',1).replace('"grid size-10 shrink-0 place-items-center rounded-lg"','"grid size-7 shrink-0 place-items-center rounded-lg sm:size-10"',1);p.write_text(s)
p=Path('src/components/partspro/admin-orders-panel.tsx');s=p.read_text();i=s.index('  return (\n    <section',s.index('export function'));j=s.index('className="',i)+len('className="');s=s[:j]+'admin-ui-panel '+s[j:];p.write_text(s)
