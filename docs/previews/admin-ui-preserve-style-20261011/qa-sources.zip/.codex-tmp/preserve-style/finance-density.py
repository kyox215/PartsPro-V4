from pathlib import Path
p=Path('src/components/partspro/admin-finance-panel.tsx');s=p.read_text()
start=s.index('function FinanceFiltersBar(');end=s.index('\nfunction MetricCard(',start)
block=s[start:end]
bodyStart=block.index('      <div className="grid gap-1"><Label htmlFor={`${id}-dateMode`}');bodyEnd=block.index('\n    </div>',bodyStart)
fields=block[bodyStart:bodyEnd]
qStart=fields.index('      <div className="order-first col-span-2')
qEnd=fields.index('</div>',qStart)+len('</div>')
search=fields[qStart:qEnd]
fields=fields[:qStart]+fields[qEnd:]
# Prefix duplicated view-only fields so the label is associated with the visible copy.
fields=fields.replace('${id}-','${id}-${layout}-')
new=block[:block.index('  return (')]+'''  const renderOptions = (layout: string) => <>
'''+fields+'''\n  </>;
  return (
    <div className="mt-3 grid min-w-0 grid-cols-2 gap-2 lg:grid-cols-3 2xl:grid-cols-[140px_140px_150px_150px_minmax(180px,1fr)_minmax(160px,1fr)_150px]">
'''+search+'''
      <details className="col-span-2 min-w-0 rounded-lg border border-slate-200 bg-white sm:hidden">
        <summary className="flex min-h-11 cursor-pointer flex-wrap items-center justify-between gap-2 px-3 text-xs font-semibold"><span>{copy.locale.startsWith("zh") ? "筛选与日期口径" : "Filtri e base della data"}</span><span className="font-mono font-normal text-slate-500">{filters.dateFrom || "—"} → {filters.dateTo || "—"}</span></summary>
        <div className="grid min-w-0 grid-cols-2 gap-2 border-t p-2">{renderOptions("mobile")}</div>
      </details>
      <div className="hidden sm:contents">{renderOptions("desktop")}</div>
      {(filters.supplier || filters.category !== "all" || filters.confidence !== "all") && <div className="col-span-2 flex min-w-0 flex-wrap gap-2 2xl:col-span-7">
        {filters.supplier && <Button type="button" variant="outline" size="sm" onClick={() => setFilters(current => ({ ...current, supplier: "" }))}>{copy.supplierPlaceholder}: {filters.supplier} ×</Button>}
        {filters.category !== "all" && <Button type="button" variant="outline" size="sm" onClick={() => setFilters(current => ({ ...current, category: "all" }))}>{copy.expenseCategory}: {expenseCategoryLabel(filters.category, copy.locale)} ×</Button>}
        {filters.confidence !== "all" && <Button type="button" variant="outline" size="sm" onClick={() => setFilters(current => ({ ...current, confidence: "all" }))}>{copy.table.confidence}: {filters.confidence} ×</Button>}
      </div>}
    </div>
  );
}
'''
s=s[:start]+new+s[end:]
# A compact metric keeps the original icon, white card and type, with less card padding.
start=s.index('function MetricCard(');end=s.index('function FinanceTable(',start)
part=s[start:end].replace('<Card className="rounded-lg border-slate-200', '<Card className="gap-0 rounded-lg border-slate-200 py-0',1)
s=s[:start]+part+s[end:];p.write_text(s)
