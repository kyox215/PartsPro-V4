const uid=n=>`00000000-0000-4000-8000-${String(n).padStart(12,'0')}`;
const date='2026-10-10T10:00:00.123456Z';
const brands=['REMAX','Apple','Samsung','Xiaomi','Huawei','OPPO','OnePlus','Honor','Motorola','Sony'];
export let nodes=[...brands.map((brand,i)=>({id:uid(900+i),kind:'brand',value:brand,nameZh:brand,nameIt:brand,active:true,position:i,version:1,count:12})),{id:uid(930),kind:'department',value:'general_merchandise',nameZh:'电子产品·高端产品',nameIt:'Elettronica e prodotti premium',active:true,position:0,version:1,count:12},{id:uid(931),kind:'category',value:'Connettori',nameZh:'连接配件',nameIt:'Connettori',active:true,position:0,version:1,count:12}];
export let products=Array.from({length:12},(_,i)=>({sku:i===0?'FIX-SKU-1':'DEMO-SKU-'+(i+1),name:i===11?'超长名称含意大利文'+('abcdefghijklmnopqrstuvwx'.repeat(4)):`REMAX 数据线 / Cavo USB professionale ${i+1}`,brand:'REMAX',category:'Connettori',catalogDepartment:'general_merchandise',grade:'A',price:10+i,retailPrice:15+i,costPrice:5,stock:i===0?0:8,availableQty:i===0?0:7,lockedQty:i===0?0:1,status:i===0?'Out of Stock':'In Stock',stockStatus:i===0?'Out of Stock':'In Stock',catalogStatus:'active',updatedAt:date,moq:1,warehouse:'Milano',compatibleWith:[],tags:[],imageUrl:'/pwa/icon-192.png',catalogUrl:'/catalogo',storefrontVisible:true,storefrontUrl:'/prodotto/demo',supplier:'Fixture supplier',modelCodes:[]}));
const verification={status:'ok',costMatches:true,quantityMatches:true,issues:[]};
const batch={id:uid(400),batchCode:'FIX-BATCH',currency:'EUR',supplierName:'Fixture supplier',invoiceNo:'DEMO-INVOICE-001',invoiceDate:'2026-10-10',receivedAt:date,totalQty:12,totalCost:60,lineQtyTotal:12,lineCostTotal:60,lineCount:1,activeProductCount:1,draftProductCount:0,missingImageCount:0,verification};
const banner={id:uid(2000),title:'演示新品到货',imagePath:'http://127.0.0.1:3179/pwa/icon-192.png',imageAlt:'Local preview placeholder',isActive:true,position:0,target:{department:'general_merchandise',brand:'REMAX'},createdAt:date,updatedAt:date};
const modelGroups=brands.map(brand=>({brand,series:[{series:brand+' Series',models:[brand+' Model 1',brand+' Model 2']}],models:[brand+' Model 1',brand+' Model 2']}));
let revision=1;
const result=(data,meta={})=>({status:200,json:{data,meta:{source:'supabase',syncedAt:date,...meta}}});
export function catalogFixture(path,method,body,params){
  if(!['GET','HEAD'].includes(method)&&!(method==='POST'&&path==='/api/admin/catalog-directory')&&!(method==='PATCH'&&path==='/api/admin/products')) return null;
  if(path==='/api/catalog-directory'||path==='/api/admin/catalog-directory'){
    if(method==='POST'){
      const existing=nodes.find(n=>n.id===body.id);
      if(existing&&body.version!==existing.version)return {status:409,json:{error:{message:'Synthetic version conflict'}}};
      revision++;
      if(existing)nodes=nodes.map(n=>n.id===body.id?{...n,...body,version:n.version+1}:n);
      else nodes.push({...body,id:uid(3000+nodes.length),active:true,count:0,version:1});
    }
    return result({nodes,revision:String(revision)});
  }
  if(path==='/api/admin/products/model-groups')return result(modelGroups);
  if(path==='/api/admin/products'){
    if(method==='PATCH'){
      products=products.map(p=>p.sku===body.sku?{...p,...body.product,updatedAt:'2026-10-11T19:00:00Z'}:p);
      return result(products.find(p=>p.sku===body.sku));
    }
    const q=(params.get('q')||'').toLowerCase();
    const rows=products.filter(p=>(!q||[p.name,p.sku,p.brand,p.supplier].join(' ').toLowerCase().includes(q))&&(!params.get('brand')||p.brand===params.get('brand'))&&(!params.get('catalogStatus')||p.catalogStatus===params.get('catalogStatus')));
    return result(rows,{total:rows.length,returned:rows.length,summary:{total:rows.length,active:rows.length}});
  }
  if(path.startsWith('/api/admin/products/')&&method==='GET')return result([]);
  if(path==='/api/admin/home-banners')return result([banner]);
  if(path==='/api/admin/supplier-batches')return result([batch],{total:1,returned:1});
  if(path==='/api/admin/supplier-batches/FIX-BATCH')return result({batch,verification,lines:[{id:uid(410),lineNo:1,qtyReceived:12,unitCost:5,lineTotal:60,skuCode:'FIX-SKU-1',name:products[0].name,productStatus:'active',imageStatus:'matched',product:{sku:'FIX-SKU-1',name:products[0].name,brand:'REMAX',category:'Connettori',catalogStatus:'active'}}],charges:[],allocations:[],history:[]});
  if(path.startsWith('/api/admin/supplier-batches/FIX-BATCH/'))return result([]);
  if(path==='/api/admin/search')return result([{id:'FIX-SKU-1',kind:'product',title:products[0].name,subtitle:'FIX-SKU-1',href:'/admin?panel=catalog&sku=FIX-SKU-1'},{id:'FIX-ORDER-001',kind:'order',title:'演示订单 FIX-ORDER-001',subtitle:'本地合成数据',href:'/admin?panel=orders&orderId='+uid(100)}],{partial:false});
  return null;
}
