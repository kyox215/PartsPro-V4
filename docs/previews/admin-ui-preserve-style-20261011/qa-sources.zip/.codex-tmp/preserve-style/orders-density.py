from pathlib import Path
p=Path('src/components/partspro/admin-orders-panel.tsx');s=p.read_text()
s=s.replace('<CardDescription className="text-xs leading-tight">','<CardDescription className="hidden text-xs leading-tight sm:block">',1)
s=s.replace('<div className="flex min-w-0 flex-col gap-2 sm:flex-row sm:items-center xl:justify-end">','<div className="flex min-w-0 items-center gap-2 xl:justify-end">',1)
s=s.replace('className="w-full sm:w-auto"\n              >\n                <TabsList', 'className="min-w-0 flex-1 sm:w-auto sm:flex-none"\n              >\n                <TabsList',1)
s=s.replace('{text.orders.syncOrders}\n              </Button>','<span className="hidden sm:inline">{text.orders.syncOrders}</span>\n              </Button>',1)
s=s.replace('className="h-8 bg-white"\n                onClick={() => void refreshOrders()}', 'className="h-8 shrink-0 bg-white"\n                aria-label={text.orders.syncOrders}\n                onClick={() => void refreshOrders()}',1)
start=s.index('          <div className="grid min-w-0 grid-cols-2 gap-2 lg:grid-cols-4">')
end=s.index('\n        </CardHeader>',start)
old=s[start:end]
# Reuse the same controlled fields in the original desktop grid and mobile details; hidden controls never participate in an action.
fields=old[old.index('            <label className="grid gap-1 text-xs font-semibold">'):old.index('\n          </div>')]
reset=old[old.index('            <Button type="button" size="xs" variant="outline" onClick='):old.index('</Button>',old.index('            <Button type="button" size="xs" variant="outline" onClick='))+len('</Button>')]
source_search=old[old.index('<AdminSearchField '):old.index(' /></label>')+len(' />')]
workflow=old[old.index('          <OrderWorkflowStrip'):]
helper='''  const activeDetailFilterCount = Number(Boolean(searchFilters.dateFrom)) + Number(Boolean(searchFilters.dateTo)) + Number(searchFilters.sort !== "operations_queue");
  const renderDateSortFilters = () => <div className="grid min-w-0 grid-cols-2 gap-2 lg:grid-cols-4">
'''+fields+'\n'+reset+'''\n  </div>;
'''
s=s[:start]+'''          <div className="grid min-w-0 gap-2">
            '''+source_search+'''
            <div className="hidden sm:block">{renderDateSortFilters()}</div>
            <div className="grid min-w-0 grid-cols-[minmax(0,1fr)_auto] gap-2 sm:block">
'''+workflow+'''
              <details className="min-w-0 self-start rounded-md border border-slate-200 bg-white open:col-span-2 sm:hidden">
                <summary className="flex min-h-11 cursor-pointer items-center gap-1 px-3 text-xs font-semibold">{locale.startsWith("it") ? "Altri filtri" : "更多筛选"}{activeDetailFilterCount > 0 && <Badge variant="outline">{activeDetailFilterCount}</Badge>}</summary>
                <div className="border-t p-2">{renderDateSortFilters()}</div>
              </details>
            </div>
            {(customerId || returnAccountId || activeDetailFilterCount > 0) && <div className="flex min-w-0 flex-wrap items-center gap-2 text-xs">
              {customerId ? <Badge variant="outline">{locale.startsWith("it") ? "Filtro cliente" : "客户筛选"}: {customerId}</Badge> : null}
              {searchFilters.dateFrom && <Button type="button" size="sm" variant="outline" onClick={() => { setPage(1); setSearchFilters(current => ({ ...current, dateFrom: "" })); }}>{locale.startsWith("it") ? "Dal" : "开始"}: {searchFilters.dateFrom} ×</Button>}
              {searchFilters.dateTo && <Button type="button" size="sm" variant="outline" onClick={() => { setPage(1); setSearchFilters(current => ({ ...current, dateTo: "" })); }}>{locale.startsWith("it") ? "Al" : "结束"}: {searchFilters.dateTo} ×</Button>}
              {searchFilters.sort !== "operations_queue" && <Button type="button" size="sm" variant="outline" onClick={() => { setPage(1); setSearchFilters(current => ({ ...current, sort: "operations_queue" })); }}>{locale.startsWith("it") ? "Ordinamento personalizzato" : "自定义排序"} ×</Button>}
              {returnAccountId ? <a className="text-primary underline" href={`/admin?panel=accounts&accountId=${encodeURIComponent(returnAccountId)}`}>{locale.startsWith("it") ? "Torna all’account" : "返回账号"}</a> : null}
            </div>}
          </div>'''+s[end:]
# Put only the low-frequency print selector after the existing list, retaining all handlers and checks.
start=s.index('          <details className="rounded-lg border p-2"><summary')
end=s.index('          </details>',start)+len('          </details>')
printing=s[start:end];s=s[:start]+s[end:]
insert=s.index('          <Dialog\n            open={mobileDetailsOpen')
s=s[:insert]+printing+'\n'+s[insert:]
# Hide only the repeated list help, not scope/data/source warnings.
s=s.replace('<p className="truncate text-xs text-slate-500">\n            {text.orders.listDescription}', '<p className="hidden truncate text-xs text-slate-500 sm:block">\n            {text.orders.listDescription}',1)
insert=s.index('  return (\n    <section className="admin-ui-panel')
s=s[:insert]+helper+'\n'+s[insert:]
p.write_text(s)
