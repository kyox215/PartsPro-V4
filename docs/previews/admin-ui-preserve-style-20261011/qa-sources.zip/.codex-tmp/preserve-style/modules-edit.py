from pathlib import Path
root=Path('src/components/partspro')
def edit(name, changes, imports=''):
 p=root/name; s=p.read_text()
 if imports:
  s=s.replace('"use client";','"use client";\n\n'+imports,1)
 for old,new in changes:
  if old not in s: raise RuntimeError((name,old[:110]))
  s=s.replace(old,new,1)
 p.write_text(s)
edit('admin-orders-panel.tsx',[
 ('<div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">','<div className="grid min-w-0 grid-cols-2 gap-2 lg:grid-cols-4">'),
 ('<label className="grid gap-1 text-xs font-semibold">{locale.startsWith("it") ? "Ordine / cliente" : "订单/客户搜索"}<Input value={orderQuery} placeholder={locale.startsWith("it") ? "Numero ordine, cliente (min. 2 caratteri)" : "订单号、客户（至少2字）"} onChange={(event) => { setPage(1); setOrderQuery(event.target.value); }} /></label>', '<label className="col-span-2 grid min-w-0 gap-1 text-xs font-semibold lg:col-span-1">{locale.startsWith("it") ? "Ordine / cliente" : "订单/客户搜索"}<AdminSearchField value={orderQuery} placeholder={locale.startsWith("it") ? "Numero ordine, cliente (min. 2 caratteri)" : "订单号、客户（至少2字）"} aria-label={locale.startsWith("it") ? "Ordine / cliente" : "订单/客户搜索"} clearLabel={text.common.reset} pending={isLoadingOrders} onValueChange={(value) => { setPage(1); setOrderQuery(value); }} /></label>'),
 ('"min-w-0 rounded-md border border-slate-200/80 bg-slate-50/60 px-2 py-1.5",','"hidden min-w-0 rounded-md border border-slate-200/80 bg-slate-50/60 px-2 py-1.5 sm:block",'),
], 'import { AdminSearchField } from "./admin-ui-controls";')
edit('admin-rma-panel.tsx',[
 ('  return (\n    <>','  const listRef = React.useRef<HTMLDivElement>(null);\n  const detailRef = React.useRef<HTMLDivElement>(null);\n\n  return (\n    <>'),
 ('<div className="relative min-w-0">\n            <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-slate-400" />','<div className="min-w-0">'),
 ('<Input\n              id="admin-rma-search"\n              className="bg-white pl-9"\n              placeholder={copy.searchPlaceholder}\n              value={searchInput}\n              onChange={(event) => setSearchInput(event.target.value)}\n            />','<AdminSearchField id="admin-rma-search" className="bg-white" placeholder={copy.searchPlaceholder} value={searchInput} onValueChange={setSearchInput} pending={isLoading} clearLabel={isZh ? "清除搜索" : "Cancella ricerca"} />'),
 ('<div className="rounded-xl border border-slate-200 bg-white p-3">\n              <div className="mb-3', '<div ref={listRef} className="scroll-mt-24 rounded-xl border border-slate-200 bg-white p-3">\n              <div className="mb-3'),
 ('onClick={() => setSelectedId(request.id)}','onClick={() => { setSelectedId(request.id); if (window.innerWidth < 1280) requestAnimationFrame(() => detailRef.current?.scrollIntoView({ block: "start" })); }}'),
 ('<div className="min-w-0 rounded-xl border border-slate-200 bg-white p-4 sm:p-5">','<div ref={detailRef} className="min-w-0 scroll-mt-24 rounded-xl border border-slate-200 bg-white p-3 sm:p-5">\n            {selectedRequest && <div className="mb-3 flex min-w-0 items-center justify-between gap-2 xl:hidden"><span className="min-w-0 truncate text-xs font-semibold text-slate-500">{isZh ? "当前售后详情" : "Dettaglio selezionato"} · {selectedRequest.rmaNo ?? copy.rma}</span><Button type="button" size="sm" variant="outline" disabled={Boolean(pendingAction) || Boolean(refundConfirmation)} onClick={() => listRef.current?.scrollIntoView({ block: "start" })}>{isZh ? "返回列表" : "Torna alla lista"}</Button></div>}'),
 ('  Search,\n',''),
], 'import { AdminSearchField } from "./admin-ui-controls";')
edit('admin-finance-panel.tsx',[
 ('className="grid h-auto group-data-horizontal/tabs:h-auto w-full grid-cols-2 rounded-lg border border-slate-200 bg-white p-1 sm:grid-cols-5"','className="flex h-auto group-data-horizontal/tabs:h-auto w-full min-w-0 overflow-x-auto rounded-lg border border-slate-200 bg-white p-1 sm:grid sm:grid-cols-5"'),
 ('className="h-auto min-h-10 whitespace-normal break-words px-2 py-2 text-center leading-tight"','className="h-auto min-h-11 min-w-20 shrink-0 flex-1 whitespace-normal break-words px-2 py-2 text-center leading-tight"'),
 ('<div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">','<div className="grid min-w-0 grid-cols-2 gap-2 md:gap-3 xl:grid-cols-4">'),
 ('<ResponsiveContainer width="100%" height="100%">','<ResponsiveContainer width="100%" height="100%" initialDimension={{ width: 320, height: 280 }}>'),
 ('<div className="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-[140px_140px_150px_150px_minmax(180px,1fr)_minmax(160px,1fr)_150px]">','<div className="mt-3 grid min-w-0 grid-cols-2 gap-2 lg:grid-cols-3 2xl:grid-cols-[140px_140px_150px_150px_minmax(180px,1fr)_minmax(160px,1fr)_150px]">'),
 ('<div className="grid gap-1"><Label htmlFor={`${id}-q`}>{copy.searchPlaceholder}</Label><Input id={`${id}-q`} value={filters.q} placeholder={copy.searchPlaceholder} onChange={(event) => setFilters((current) => ({ ...current, q: event.target.value }))} /></div>','<div className="order-first col-span-2 grid min-w-0 gap-1 lg:col-span-1 2xl:order-none"><Label htmlFor={`${id}-q`}>{copy.searchPlaceholder}</Label><AdminSearchField id={`${id}-q`} value={filters.q} placeholder={copy.searchPlaceholder} clearLabel={copy.locale.startsWith("zh") ? "清除搜索" : "Cancella ricerca"} onValueChange={(q) => setFilters((current) => ({ ...current, q }))} /></div>'),
 ('className="flex min-h-[112px] items-start justify-between gap-3 p-4"','className="flex min-h-[96px] min-w-0 items-start justify-between gap-2 p-3 md:min-h-[112px] md:gap-3 md:p-4"'),
 ('className="mt-2 truncate font-mono text-2xl font-black text-slate-950"','className="mt-2 break-all font-mono text-lg font-black text-slate-950 md:text-2xl"'),
 ('className="grid size-9 shrink-0 place-items-center rounded-lg bg-primary/10 text-primary"','className="grid size-7 shrink-0 place-items-center rounded-lg bg-primary/10 text-primary md:size-9"'),
], 'import { AdminSearchField, AdminSearchableSelect } from "./admin-ui-controls";')
edit('admin-activity-timeline.tsx',[
 ('"overflow-hidden border-slate-200 bg-white shadow-[0_18px_45px_rgba(15,23,42,0.05)]",','"admin-ui-panel overflow-hidden border-slate-200 bg-white shadow-[0_18px_45px_rgba(15,23,42,0.05)]",'),
 ('<div className="flex w-full min-w-0 flex-col gap-2 sm:flex-row xl:w-auto xl:justify-end">','<div className="grid w-full min-w-0 grid-cols-2 gap-2 sm:flex xl:w-auto xl:justify-end">'),
 ('<div className="relative min-w-0 flex-1 xl:w-[260px] xl:flex-none">\n            <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-slate-400" />\n            <Input\n              value={query}\n              onChange={(event) => setQuery(event.target.value)}\n              className="h-9 bg-white pl-9"\n              aria-label={copy.searchPlaceholder}\n              placeholder={copy.searchPlaceholder}\n            />\n          </div>', '<AdminSearchField containerClassName="col-span-2 min-w-0 flex-1 xl:w-[260px] xl:flex-none" value={query} onValueChange={setQuery} className="bg-white" aria-label={copy.searchPlaceholder} placeholder={copy.searchPlaceholder} clearLabel={locale.startsWith("zh") ? "清除搜索" : "Cancella ricerca"} />'),
 ('  Search,\n',''),
], 'import { AdminSearchField } from "./admin-ui-controls";')
edit('admin-analytics-panel.tsx',[
 ('<div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">','<div className="grid min-w-0 grid-cols-2 gap-2 sm:gap-3 xl:grid-cols-4">'),
])
edit('admin-remax-center.tsx',[
 ('<div className="grid gap-3 xl:grid-cols-[minmax(0,1.25fr)_minmax(360px,0.75fr)]">','<div className="grid min-w-0 grid-cols-1 gap-3 xl:grid-cols-[minmax(0,1.25fr)_minmax(360px,0.75fr)]">'),
 ('<section className="space-y-3">','<section className="min-w-0 space-y-3">'),
 ('<div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">','<div className="grid min-w-0 grid-cols-2 gap-2 lg:grid-cols-3">'),
 ('<Field label={t("Codice lotto *")}>','<Field className="col-span-2 lg:col-span-1" label={t("Codice lotto *")}>'),
 ('<Field label={t("Chiusura prenotazioni")}>','<Field className="col-span-2 lg:col-span-1" label={t("Chiusura prenotazioni")}>'),
 ('<div className="max-h-96 overflow-auto rounded-lg border border-slate-200">','<p className="text-xs text-slate-500 lg:hidden">{locale.startsWith("zh") ? "横向滑动查看价格与预检结果" : "Scorri per vedere prezzi ed esito dei controlli"}</p>\n                  <div className="max-h-96 overflow-auto rounded-lg border border-slate-200">'),
 ('<select className="h-10 w-full rounded-md border border-input bg-white px-3 text-sm" value={props.selectedBatchCode} onChange={(event) => props.onSelectBatch(event.currentTarget.value)}>\n            <option value="">{t("Seleziona lotto")}</option>\n            {props.batches.map((batch) => <option key={batch.id} value={batch.batchCode}>{batch.batchCode} {t("· residuo")}{batch.remainingQty}</option>)}\n          </select>', '<AdminSearchableSelect value={props.selectedBatchCode} onValueChange={props.onSelectBatch} ariaLabel={t("Lotto arrivato")} placeholder={t("Seleziona lotto")} searchPlaceholder={locale.startsWith("zh") ? "搜索批次" : "Cerca lotto"} options={props.batches.map(batch => ({ value: batch.batchCode, label: `${batch.batchCode} ${t("· residuo")}${batch.remainingQty}` }))} />'),
], 'import { AdminSearchableSelect } from "./admin-ui-controls";')
