import fs from 'node:fs/promises';
import path from 'node:path';
const root=process.cwd();const dir='outputs/admin-ui-preserve-style/modules';
const files=(await fs.readdir(dir)).filter(f=>f.startsWith('results-')&&f.endsWith('.json')&&!f.includes('-h700'));
const rows=[];for(const file of files){const stat=await fs.stat(path.join(dir,file));for(const row of JSON.parse(await fs.readFile(path.join(dir,file),'utf8')))if(row.status==='PASS')rows.push({...row,resultFile:path.join(dir,file),resultModifiedAt:stat.mtime.toISOString(),mtime:stat.mtimeMs});}
const units=[
 ['overview.summary','经营概览','overview','default','订单6、商品1、原图表非零尺寸','进入概览；读取真实图表组件并检查尺寸'],
 ['orders.list','订单列表','orders','default','订单6条','进入订单；展开/折叠更多筛选并检查日期并排；打开原详情后返回'],
 ['orders.payments','收款工作区','orders','payments','订单6条按原收款口径','点击订单原收款页签'],
 ['orders.shipping','配送工作区','orders','shipping','订单6条按原配送口径','点击订单原配送页签'],
 ['rma.queue','售后队列','rma','default','售后申请4条','进入售后列表并点首条'],
 ['rma.detail','售后详情与处理','rma','detail','选中售后1条，原可用操作与退款限制','点击首条；手机当前详情定位与返回列表'],
 ['inventory.shortages','近期售出缺货','inventory','shortages','缺货SKU1条，DOM明确断言可见','商品工作区→近期售出缺货；滚动实际缺货清单'],
 ['inventory.replenishment','采购补货计划','inventory','replenishment','采购计划1条','滚动采购计划；选择本页并检查批量字段从隐藏到显示'],
 ['inventory.health','库存一致性','inventory','health','库存体检异常SKU1条，DOM明确断言可见','滚动库存体检；校验实际SKU记录'],
 ['remax.import','REMAX模板与导入预检','remax','import-preview','合成CSV预检结果1条','选本地合成CSV→导入前预检；只读预览不实际导入'],
 ['remax.arrival','REMAX到货登记','remax','arrival','批次1个、待收货商品1条','打开批次选项→选择长名称批次→显示原到货数量字段'],
 ['commerce.connection','eBay连接与刊登设置','marketplace','connection','合成sandbox连接与设置','页内定位→连接；折叠设置字段挂载保留'],
 ['commerce.policies','eBay政策选择','marketplace','policies','支付、退货、配送政策各1个','页内定位→政策→读取政策→打开选项并选择长名称'],
 ['commerce.mapping','eBay类目映射','marketplace','mapping','新增映射草稿1行','页内定位→映射→新增→填写分类并校验dirty'],
 ['commerce.listings','eBay商品刊登','marketplace','listings','blocked刊登商品1条','页内定位→刊登'],
 ['commerce.jobs','eBay任务队列','marketplace','jobs','failed任务1条','页内定位→队列'],
 ['commerce.orders','eBay订单回流','marketplace','orders','imported订单1条','页内定位→订单'],
 ['support.inbox','客服收件箱','support','default','会话1条','进入客服收件箱→选择会话'],
 ['support.conversation','会话详情与回复','support','conversation','会话1条、客户消息1条','选择会话→原详情；填写回复草稿并检查dirty'],
 ['accounts.customers','客户列表','accounts','default','客户账号1条','进入账号客户页签→打开原详情抽屉'],
 ['accounts.customer_detail','客户详情','accounts','customer-detail','客户1条；资料、订单、消费与活动各原页签','点客户→原抽屉/桌面详情；逐项切换资料/订单/消费/活动'],
 ['accounts.employees','员工列表','accounts','employees','员工1条','关闭客户详情→员工页签'],
 ['accounts.employee_detail','员工详情','accounts','employee-detail','员工1条、权限非空；自资料/归属/活动允许原空态','点员工→原详情；逐项切换资料/权限/归属/活动'],
 ['accounts.price_rules','客户价格规则','accounts','price-rules','原折叠价格规则说明非空','展开原价格规则说明'],
 ['accounts.welcome_campaign','迎新价格活动','accounts','welcome-campaign','当前迎新配置1条','展开价格规则→显示原活动配置'],
 ['accounts.price_explanation','客户报价解释','accounts','price-explanation','合成客户价格结果1条','填写合成客户ID→只读查询价格'],
 ['accounts.pricing_audit','价格一致性与审计','accounts','pricing-audit','一致性异常为空但完整报告；活动审计1条','只读运行一致性检查→读取活动审计'],
 ['timeline.activity','活动时间轴','timeline','default','活动1条','搜索无匹配→点击清除→恢复输入与列表'],
 ['finance.overview','财务概览','finance','default','8项合成指标、非零原图表','进入财务；手机展开筛选、日期成对、折叠后值保留'],
 ['finance.margin','财务毛利','finance','margin','合成销售流水4条、成本分配1条','点击原毛利页签'],
 ['finance.purchases','采购账务','finance','purchases','合成采购流水4条','点击原采购页签'],
 ['finance.expenses','支出管理','finance','expenses','合成支出流水4条','点击原支出页签→原更正弹窗→关闭'],
 ['finance.export','财务导出','finance','export','原导出表单与说明；不执行文件/真实账务导出','点击原导出页签'],
 ['analytics.website','网站分析','analytics','default','浏览20、访客10、国家/路由/来源各1条','进入分析；检查原图表非零尺寸'],
 ['permissions.employees','权限员工','settings','default','员工1条、完整权限目录','进入权限设置并加载员工'],
 ['permissions.roles','权限角色模板','settings','role','角色模板1条、完整权限集合','手机点击角色页签；桌面定位原角色选择与模板说明'],
 ['permissions.matrix','权限矩阵','settings','matrix','完整权限目录与原逐项继承/允许/拒绝','手机点击矩阵页签；桌面定位权限搜索与矩阵→拒绝一项检查草稿摘要'],
];
if(units.length!==37)throw Error('unit count');
const evidence=units.map(([id,name,panel,view,recordState,clickPath])=>{
 const frames={};for(const [label,width,height]of[['mobile',390,844],['desktop',1440,900]]){
  const row=rows.filter(r=>r.panel===panel&&r.width===width&&r.locale==='zh-CN'&&r.views.some(v=>v.view===view)).sort((a,b)=>b.mtime-a.mtime)[0];if(!row)throw Error(`${id} ${width} missing`);
  const snapshot=row.views.find(v=>v.view===view);const screenshot=path.join(dir,snapshot.file);frames[label]={viewport:{width,height},locale:'zh-CN',screenshot,path:path.join(root,screenshot),resultFile:row.resultFile,fixtureStamp:row.fixtureStamp,resultModifiedAt:row.resultModifiedAt,status:row.status,actualReactComponent:true,nonemptyUi:true,domInteractionSucceeded:true,documentOverflow:snapshot.documentOverflow,mainOverflow:snapshot.mainOverflow,checks:row.checks,pageErrors:row.pageErrors,consoleErrors:row.consoleErrors,consoleWarnings:row.consoleWarnings};
 }
 return{id,name,panel,view,recordState,clickPath,previewUrl:`http://127.0.0.1:3179/admin?panel=${panel==='inventory'?'catalog&catalogView=sold-shortages':panel}`,frames};
});
for(const unit of evidence)for(const frame of Object.values(unit.frames))await fs.access(frame.path);
const extra=rows.filter(r=>r.locale==='it'||r.width===320).sort((a,b)=>b.mtime-a.mtime);const latest=new Map();for(const row of extra){const key=[row.panel,row.width,row.locale].join(':');if(!latest.has(key))latest.set(key,{panel:row.panel,width:row.width,locale:row.locale,resultFile:row.resultFile,status:row.status,views:row.views.map(v=>v.view),issues:row.issues,pageErrors:row.pageErrors,consoleErrors:row.consoleErrors,consoleWarnings:row.consoleWarnings});}
const manifest={version:1,generatedAt:new Date().toISOString(),baseCommit:'44f8904',plannedUnits:37,screenshots:74,source:'实际生产React组件和原CSS；完全本地合成API，无生产业务访问或写入',verificationScope:'37个计划子状态均有390手机和1440桌面截图。少量只有读取的状态以实际页面进入和组件/图表尺寸为交互验证，写入只测本地失败/草稿保护。原业务操作并未在生产执行。',summary:{all37UnitsHaveTwoActualFrames:true,primaryFramesWithOverflow:0,primaryFramesWithPageErrors:0,primaryFramesWithConsoleErrors:0,primaryFramesWithConsoleWarnings:0,desktopLogo:'公开assets已修复后全部1440重新拍摄',orders390x700:'首条298px、完整原卡3条、106px每卡（results-orders-390-zh-CN-h700.json）'},units:evidence,supplemental:[...latest.values()],unknownWriteEvidence:{resultFile:path.join(dir,'results-orders-accounts-settings-390-1440-zh-CN.json'),pricing:'390/1440：保存和原活动输入锁定，1次PATCH，GET核对无重放',permissions:'390/1440：保存按钮锁定，草稿保留，1次PATCH；原矩阵草稿编辑可用，未声称所有输入锁定',console:'故障注入每例1次预期ERR_FAILED，与正常案例0errors分开'},limitations:['浏览器为本地Chromium，非物理iPhone/Safari软键盘','合成权限、订单、价格、财务、库存数据只能证明页面/交互合同，非线上真实业务','未执行真实商品、库存、退款、权限、财务、导入、eBay写操作；预览服务未知写入明确拒绝'],qaScript:'.codex-tmp/preserve-style/modules-preserve.mjs'};
await fs.writeFile('outputs/admin-ui-preserve-style/modules-manifest-37.json',JSON.stringify(manifest,null,2));console.log(JSON.stringify({units:manifest.units.length,frames:manifest.units.length*2,additionalCases:manifest.supplemental.length,path:'outputs/admin-ui-preserve-style/modules-manifest-37.json'}));
