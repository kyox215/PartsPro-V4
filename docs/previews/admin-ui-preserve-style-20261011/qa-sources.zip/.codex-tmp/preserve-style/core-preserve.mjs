import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {createRequire} from 'node:module';
const {chromium}=createRequire('/Users/kyox215/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/package.json')('playwright');
const out='outputs/admin-ui-preserve-style/core';await fs.mkdir(out,{recursive:true});
const browser=await chromium.launch({channel:'chrome',headless:true});const results=[];
try{
for(const [width,height,locale] of [[320,700,'zh-CN'],[390,700,'zh-CN'],[430,844,'it'],[768,900,'it'],[1440,900,'zh-CN']]){
 const context=await browser.newContext({viewport:{width,height}});const page=await context.newPage();page.setDefaultTimeout(10000);
 const errors=[],warnings=[],requests=[],external=[];let expectedFailure=false;
 page.on('dialog',dialog=>dialog.accept());page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='warning')warnings.push(m.text());if(m.type()==='error'&&!expectedFailure)errors.push(m.text());});
 await context.route('**/*',r=>{const u=new URL(r.request().url());if(u.hostname==='127.0.0.1'){if(u.pathname.startsWith('/api/'))requests.push({path:u.pathname,method:r.request().method()});return r.continue();}external.push(u.href);return r.abort();});
 const zh=locale.startsWith('zh');
 async function goto(view='products'){await page.goto(`http://127.0.0.1:3179/admin?panel=catalog&catalogView=${view}&locale=${locale}`);}
 async function shot(name){await page.screenshot({animations:'disabled',path:`${out}/${name}-${width}-${locale}.png`});}
 function noOverflow(){return page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1);}
 async function changeView(view,label){if(width<640){await page.getByRole('button',{name:zh?'商品工作区':'Area catalogo',exact:true}).click();await page.getByRole('menuitem',{name:label,exact:true}).click();}else await page.getByRole('tab',{name:label,exact:true}).click();}
 try{
  await goto();await page.locator(width<1024?'[data-admin-product-card]':'tbody tr').first().waitFor();
  assert.ok(await noOverflow(),'product viewport overflow');
  const productMetrics=await page.locator('[data-admin-product-card]').evaluateAll(els=>els.map(e=>{const r=e.getBoundingClientRect();return {top:r.top,bottom:r.bottom,height:r.height};}));
  const productsVisible=productMetrics.filter(r=>r.height>0&&r.top>=0&&r.bottom<=height).length;
  if(width===390)assert.ok(productsVisible>=3,`three original product cards (${productsVisible}, first=${productMetrics[0]?.top})`);
  await shot('products');
  const search=page.getByRole('textbox',{name:zh?'搜索 SKU / 商品 / 品牌 / 型号':'Cerca SKU / prodotto / brand / modello',exact:true});
  assert.equal(await search.count(),1,'list search present');{await search.fill('DEMO-SKU-2');await page.getByRole('button',{name:zh?'清除搜索':'Azzera ricerca',exact:true}).filter({visible:true}).first().click();await search.focus();assert.equal(await search.inputValue(),'');}
  if(width===390||width===1440){
   if(width===1440){await page.locator('tbody tr').first().getByRole('button').last().click();await page.getByRole('menuitem',{name:'编辑商品',exact:true}).click();}else await page.getByRole('button',{name:'编辑商品',exact:true}).first().click();const editor=page.getByRole('dialog');await editor.waitFor();await editor.getByRole('group',{name:'商品名称',exact:true}).getByRole('textbox').fill('演示商品编辑');await shot('product-editor');
   await editor.getByRole('button',{name:'取消',exact:true}).first().click();await editor.getByRole('button',{name:'关闭',exact:true}).click().catch(async()=>{await page.keyboard.press('Escape');});
   await page.getByRole('button',{name:'筛选',exact:false}).first().click();await page.getByRole('dialog').waitFor();await shot('product-filters');await page.getByRole('dialog').getByRole('button',{name:'关闭',exact:true}).click();
  }
  await changeView('directory',zh?'目录管理':'Gestione catalogo');await page.getByRole('button',{name:zh?'品牌':'Brand',exact:true}).click();await page.locator('[data-catalog-node]').first().waitFor();
  const directory=await page.locator('[data-catalog-node]').evaluateAll(els=>els.map(e=>{const r=e.getBoundingClientRect();return {top:r.top,bottom:r.bottom,height:r.height};}));
  const directoryVisible=directory.filter(r=>r.height>0&&r.top>=0&&r.bottom<=height).length;if(width===390)assert.ok(directoryVisible>=5,'five directory items');assert.ok(await noOverflow());await shot('directory');
  await page.locator('[data-catalog-node]').first().locator('button').first().click();const form=page.locator('#catalog-node-editor');await form.waitFor();await shot('directory-editor');
  if(width===390){
   const field=form.locator('#catalog-node-nameZh');await field.fill('目录草稿仍应保留');
   await context.route('**/api/admin/catalog-directory',async route=>{if(route.request().method()==='POST')await route.fulfill({status:409,json:{error:{message:'Synthetic conflict'}}});else await route.continue();});expectedFailure=true;
   await form.getByRole('button',{name:'保存目录',exact:true}).click();await page.locator('[data-admin-notice=warning]').first().waitFor();assert.equal(await field.inputValue(),'目录草稿仍应保留');await shot('directory-conflict');await context.unroute('**/api/admin/catalog-directory');
   let writes=0;await context.route('**/api/admin/catalog-directory',async route=>{if(route.request().method()==='POST'){writes++;await route.fetch();await route.fulfill({status:503,json:{error:{message:'Synthetic unknown after commit'}}});}else await route.continue();});
   await form.getByRole('button',{name:'保存目录',exact:true}).click();await page.getByRole('button',{name:'查询保存结果',exact:true}).waitFor();assert.ok(await form.getByRole('button',{name:'保存目录',exact:true}).isDisabled());assert.ok(await field.isDisabled());await shot('directory-unknown');
   await page.getByRole('button',{name:'查询保存结果',exact:true}).click();await form.waitFor({state:'hidden'});assert.equal(writes,1,'unknown readback must not replay POST');await context.unroute('**/api/admin/catalog-directory');expectedFailure=false;
  }else await form.getByRole('button',{name:zh?'关闭':'Chiudi',exact:true}).click();
  await changeView('banners',zh?'首页横幅':'Banner homepage');await page.getByRole('combobox',{name:zh?'品牌':'Brand',exact:true}).waitFor();await shot('banners');
  const combo=page.getByRole('combobox',{name:zh?'品牌':'Brand',exact:true});await combo.focus();await page.keyboard.press('ArrowDown');await page.getByRole('listbox').waitFor();const optionSearch=page.getByRole('textbox',{name:zh?'搜索选项':'Cerca opzioni',exact:true});await optionSearch.fill('sam');await page.getByRole('option',{name:'Samsung',exact:true}).waitFor();await shot('searchable-options');await optionSearch.press('Enter');assert.match(await combo.innerText(),/Samsung/);
  await combo.click();await optionSearch.fill('__none__');assert.equal(await page.getByRole('option').count(),0);await optionSearch.press('Enter');assert.equal(await page.getByRole('listbox').count(),1);await optionSearch.press('Escape');await page.getByRole('listbox').waitFor({state:'hidden'});assert.match(await combo.innerText(),/Samsung/);assert.ok(await noOverflow());
  await goto('batches');await page.getByText('FIX-BATCH',{exact:true}).filter({visible:true}).first().waitFor();await shot('batches');
  const batchDetail=page.getByRole('button',{name:zh?'查看明细':'Dettaglio',exact:true}).filter({visible:true});assert.ok(await batchDetail.count(),'batch detail control');{await batchDetail.first().click();await page.getByRole('dialog').waitFor();await shot('batch-detail');await page.keyboard.press('Escape');}
  await goto();await page.locator(width<1024?'[data-admin-product-card]':'tbody tr').first().waitFor();
  if(width===390||width===1440){await page.getByRole('button',{name:'Excel 导入',exact:true}).click();await page.getByRole('dialog').waitFor();await shot('excel-import');await page.keyboard.press('Escape');}
  await page.getByRole('button',{name:zh?'搜索订单、商品和账号':'Cerca ordini, prodotti e account',exact:true}).click();const global=page.getByRole('dialog');await global.getByRole('textbox',{name:zh?'搜索关键字':'Termine di ricerca',exact:true}).fill('FIX');await global.getByRole('link').first().waitFor();await shot('global-search');await global.getByRole('button',{name:zh?'清除搜索':'Azzera ricerca',exact:true}).click();assert.equal(await global.getByRole('link').count(),0);await page.keyboard.press('Escape');
  if(width<1024){await page.getByRole('button',{name:zh?'打开后台导航':'Apri navigazione admin',exact:true}).click();const menu=page.getByRole('dialog');const menuSearch=menu.getByRole('textbox',{name:zh?'搜索后台菜单':'Cerca menu',exact:true});await menuSearch.fill(zh?'订单':'Ordini');await shot('menu-search');await menu.getByRole('button',{name:zh?'清除搜索':'Azzera ricerca',exact:true}).click();await page.keyboard.press('Escape');}
  assert.deepEqual(errors,[]);assert.deepEqual(external,[]);results.push({width,height,locale,productsVisible,directoryVisible,directoryTop:directory[0]?.top,overflow:false,pageErrors:errors.length,warnings,expectedConflictAndUnknown:width===390,apiRequests:requests.length});
 }catch(e){await shot('failure');console.log('FAIL',width,e.message,errors,external);throw e;}finally{await context.close();}
}
await fs.writeFile(out+'/results.json',JSON.stringify(results,null,2));console.log(JSON.stringify(results));
}finally{await browser.close();}
