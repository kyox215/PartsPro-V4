import React from 'react';
export const useLinkStatus=()=>({pending:false});
export default function Link({href,children,prefetch,...props}:any){return <a href={href} {...props}>{children}</a>;}
