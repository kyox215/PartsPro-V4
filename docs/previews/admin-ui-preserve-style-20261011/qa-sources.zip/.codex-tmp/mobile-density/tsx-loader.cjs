const ts = require(process.cwd() + '/node_modules/typescript');
module.exports = function(source) { return ts.transpileModule(source,{ compilerOptions:{ target:ts.ScriptTarget.ES2020,module:ts.ModuleKind.ESNext,jsx:ts.JsxEmit.ReactJSX,esModuleInterop:true }}).outputText; };
