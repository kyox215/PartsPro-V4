export async function setLocale(locale:string){return locale;}
