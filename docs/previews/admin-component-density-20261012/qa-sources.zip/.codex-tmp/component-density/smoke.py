import json,subprocess,tempfile,os,sys,re
from pathlib import Path
from urllib.parse import urlparse
phase=sys.argv[1];target=sys.argv[2]
checks=[('/',[200]),('/catalogo',[200]),('/api/catalog-directory',[200]),('/admin',[307,308,302,200]),('/api/admin/products',[401]),('/api/admin/catalog-directory',[401]),('/api/admin/orders',[401]),('/api/admin/rma',[401]),('/api/admin/finance/summary',[401]),('/api/admin/support/conversations',[401]),('/sw.js',[200])]
results=[]
for route,expected in checks:
 fd,p=tempfile.mkstemp(prefix='smoke-',dir='.codex-tmp/preserve-style');os.close(fd)
 cmd=['vercel','curl',route,'--deployment',target,'--scope','team_AOJDnrjov0QDLqpvMyhwA1yc','--','--silent','--show-error','--max-time','45','--output',p,'--write-out','{"status":%{http_code},"redirect":"%{redirect_url}"}']
 if phase=='production':cmd=['curl','--silent','--show-error','--max-time','45','--output',p,'--write-out','{"status":%{http_code},"redirect":"%{redirect_url}"}','https://'+target+route]
 r=subprocess.run(cmd,capture_output=True,text=True)
 body=Path(p).read_text();Path(p).unlink()
 try:stats=json.loads(r.stdout)
 except:raise RuntimeError('Deployment read failed for '+route)
 row={'path':route,'status':stats['status'],'redirectPath':urlparse(stats.get('redirect','')).path,'pass':r.returncode==0 and stats['status'] in expected}
 if route=='/api/catalog-directory' and row['pass']:
  data=json.loads(body).get('data',{});nodes=data.get('nodes',[]);names=[n.get('nameZh','') for n in nodes if n.get('kind')=='department' and n.get('value')=='general_merchandise'];row['directoryNodes']=len(nodes);row['generalMerchandiseLabel']=names;row['pass']=len(nodes)>0 and any('电子产品' in name and '高端产品' in name for name in names)
 if route=='/admin':
  row['loginMeta']=bool(re.search(r'<meta[^>]+http-equiv="refresh"[^>]+/login',body));row['streamRedirectLogin']='NEXT_REDIRECT' in body and '/login?next=' in body;row['adminWorkspaceRendered']='data-admin-ui="true"' in body
  row['pass']=row['pass'] and (row['redirectPath'].startswith('/login') or (stats['status']==200 and row['loginMeta'] and row['streamRedirectLogin'] and not row['adminWorkspaceRendered']))
 results.append(row);print(json.dumps(row,ensure_ascii=False),flush=True)
Path('outputs/admin-component-density-20261012/release/'+phase+'-smoke.json').write_text(json.dumps({'target':target,'mode':'GET only; direct public HTTPS without cookies' if phase=='production' else 'GET only; Vercel protection accepted, app session anonymous','checks':results},ensure_ascii=False,indent=2))
assert all(row['pass'] for row in results)
