import hashlib, json, shutil
from pathlib import Path

root = Path.cwd()
target = root / 'docs/previews/admin-component-density-20261012'
screens = target / 'screens'
screens.mkdir(parents=True, exist_ok=True)
current = root / 'outputs/admin-component-density-20261012'
previous = root / 'docs/previews/admin-ui-preserve-style-20261011/screens'

def shot(source, name):
    dst = screens / name
    shutil.copyfile(source, dst)
    return {'path': 'screens/' + name, 'sha256': hashlib.sha256(dst.read_bytes()).hexdigest()}

definitions = [
    ('inventory', '库存统计与体检', '8 项统计改为两组横排摘要，体检 4 项保留两列。', '8 项 160px · 体检 62px', 'catalog&catalogView=sold-shortages', 'inventory-health', 'modules/inventory-stats', 'modules/inventory-desktop'),
    ('rma', '售后详情', '商品名最多两行，客户名一行；点击名称旁的展开图标查看全文。', '身份信息 193px', 'rma', 'rma-detail', 'rma-compact', 'rma-compact'),
    ('excel', 'Excel 导入预检', '标题和当前步骤合并，7 项统计改为紧凑摘要，说明按需展开。', '标题 77px · 7 项 122px', 'catalog', 'excel-import-blocked', 'excel-blocked', 'excel-blocked'),
    ('finance', '财务摘要', '标签与完整金额横排；大金额自动改为单列，保留币种和百分比。', '正常摘要 137px', 'finance', 'finance-default', 'modules/finance-stats', 'modules/finance-desktop'),
    ('overview', '经营概览', '手机端 6 项指标集中呈现，统计口径和原对比数据按需展开。', '6 项约 92–103px', 'overview', 'overview-default', 'modules/overview-stats', 'modules/overview-desktop'),
    ('analytics', '访问分析', '4 项指标使用同一摘要排版，指标说明集中折叠。', '4 项约 76–92px', 'analytics', 'analytics-default', 'modules/analytics-stats', 'modules/analytics-desktop'),
    ('product', '商品详情名称', '详情名称最多两行，原查看和编辑入口继续保留。', '复用名称展开', 'catalog', None, 'product-detail', 'product-detail'),
    ('batch', '到货批次商品名称', '限制名称列宽，超长名称可展开，不挤占数量与成本列。', '复用名称展开', 'catalog&catalogView=batches', None, 'batch-detail', 'batch-detail'),
    ('remax', 'REMAX 到货名称', '到货商品名一行摘要，点击查看全文，数量输入继续完整显示。', '复用名称展开', 'remax', 'remax-arrival', 'remax-arrival', 'remax-arrival'),
]
cards = []
for key, title, description, metric, panel, before, phone, desktop in definitions:
    card = dict(id=key, title=title, description=description, metric=metric,
                workspace='/admin?panel=' + panel + '&locale=zh-CN', shots={})
    for device, width, source_name in [('mobile', 390, phone), ('desktop', 1440, desktop)]:
        filename = f'{source_name}-{width}-zh-CN.png'
        card['shots'][device] = {'after': shot(current / filename, f'{key}-after-{device}.png')}
        if before:
            card['shots'][device]['before'] = shot(previous / f'{before}-{width}-zh-CN.png', f'{key}-before-{device}.png')
        full = {'rma': 'rma-name-full', 'product': 'product-detail-name-full', 'batch': 'batch-detail-name-full', 'remax': 'remax-arrival-name-full'}.get(key)
        if full:
            card['shots'][device]['full'] = shot(current / f'{full}-{width}-zh-CN.png', f'{key}-full-{device}.png')
        if key == 'excel':
            card['shots'][device]['full'] = shot(current / f'excel-ready-confirmed-{width}-zh-CN.png', f'{key}-confirmed-{device}.png')
    cards.append(card)

manifest = dict(title='后台紧凑组件预览', date='2026-10-12', status='production-released', applicationCommit='4f30c3eee59034131d691d972a5f92daabd0a72e', deploymentId='dpl_F4MW4NgmxFWHndeVTzNk9MzRPuur', productionUrl='https://www.partspro.app/admin',
                baseline='acf1f841767aa238812d3747cc99dfd3747454ab',
                branch='codex/admin-component-density-20261012',
                runtime='actual React components and project CSS; local synthetic API and Next navigation/image stubs',
                productionWrites=False, cards=cards)
(target / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
html = '''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>PartsPro · 后台紧凑组件预览</title><style>
*{box-sizing:border-box}body{margin:0;background:#f6f8fc;color:#17243b;font:14px/1.5 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif}button,a,input{font:inherit}button{min-height:44px;border:1px solid #dbe2ef;border-radius:8px;background:white;color:inherit;padding:8px 12px;cursor:pointer}button:focus-visible,a:focus-visible{outline:2px solid #3b5bff;outline-offset:2px}button.active{color:#3158e5;background:#eef1ff;border-color:#bccafa}button:disabled{color:#94a3b8;cursor:default}header{padding:18px 24px;background:white;border-bottom:1px solid #dfe5ee}h1{font-size:22px;margin:0}p{margin:5px 0;color:#63718a}.status{display:inline-block;margin:0 0 5px;padding:2px 7px;border:1px solid #bfcced;background:#f0f5ff;border-radius:6px;font-size:12px;color:#3b5b9d}main{max-width:1500px;margin:auto;padding:16px}.rules{display:flex;gap:6px;flex-wrap:wrap;margin:0 0 12px}.rules span{padding:5px 9px;background:#fff;border:1px solid #dfe5ee;border-radius:6px;font-size:12px}.toolbar{display:flex;align-items:center;gap:8px;flex-wrap:wrap;position:sticky;top:0;z-index:1;padding:8px 0;background:#f6f8fc}.toolbar a{margin-left:auto;color:#365de8;min-height:44px;display:flex;align-items:center}.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(270px,1fr));gap:12px}.card{border:1px solid #dfe5ee;border-radius:8px;overflow:hidden;background:#fff;min-width:0}.meta{padding:12px}.meta h2{font-size:16px;margin:0}.meta p{font-size:12px;min-height:36px}.metric{color:#365de8;font-size:12px;font-weight:600}.thumb{border:0;border-top:1px solid #e2e8f0;border-radius:0;background:#f1f4f9;width:100%;height:360px;padding:0;display:block;cursor:zoom-in}.thumb img{height:100%;max-width:100%;object-fit:contain;object-position:top}.thumb.desktop{height:220px}.actions{display:flex;gap:6px;padding:8px;border-top:1px solid #e2e8f0}.actions button{flex:1;min-width:0;font-size:12px;padding:6px}.note{font-size:12px;margin:16px 0}.detail{padding:0;width:min(1490px,96vw);height:94dvh;border:1px solid #dfe5ee;border-radius:8px;background:#f6f8fc}.detail::backdrop{background:#0f172acc}.detailbar{display:flex;align-items:center;gap:6px;flex-wrap:wrap;padding:8px;background:#fff;border-bottom:1px solid #dfe5ee}.detailbar strong{flex:1;min-width:160px}.canvas{height:calc(100% - 108px);overflow:auto;padding:12px;text-align:center}.canvas>img{max-width:100%;height:auto;background:white;border:1px solid #dfe5ee}.canvas iframe{max-width:100%;height:100%;border:1px solid #dfe5ee;background:white}.compare{display:grid;grid-template-columns:1fr 1fr;gap:12px;max-width:1300px;margin:auto}.compare img{max-width:100%;height:auto;vertical-align:top}.compare figure{margin:0}.compare figcaption{position:sticky;top:0;background:#f6f8fc;font-weight:bold;padding:6px}.help{font-size:12px;margin:0;padding:6px 12px;background:white;color:#63718a}.detailbar button{font-size:12px}#close{margin-left:auto}.empty{padding:30px;color:#63718a}@media(max-width:600px){header{padding:12px}main{padding:10px}h1{font-size:20px}.grid{grid-template-columns:1fr 1fr;gap:8px}.meta{padding:8px}.meta h2{font-size:13px}.meta p{min-height:72px}.thumb{height:260px}.thumb.desktop{height:160px}.actions{flex-direction:column;padding:6px}.detailbar strong{flex-basis:100%;font-size:14px}.detailbar button{flex:1;padding:6px}.canvas{height:calc(100% - 160px);padding:4px}.compare{grid-template-columns:1fr}.toolbar a{margin:0}.rules span{flex:1;min-width:120px}}
</style></head><body><header><span class="status">已上线 · 4f30c3e</span><h1>后台紧凑组件预览</h1><p>保留现有配色、卡片与导航，重点减少重复的竖向空间。</p></header><main><div class="rules"><span>统计：标签与数字横排</span><span>名称：最多 1–2 行，点击看全文</span><span>说明：按需展开，确认步骤保留</span></div><div class="toolbar"><button id="mobile" class="active" aria-pressed="true">手机 390px</button><button id="desktop" aria-pressed="false">电脑 1440px</button><a href="/ui-preview-original/">上次 44 组预览</a></div><div class="grid" id="grid"></div><p class="note">截图来自实际组件与项目 CSS，全部使用本地合成数据。交互工作区不会连接生产数据库；预检返回固定示例。物理 iPhone、Safari 软键盘与真实业务交易尚未验收。</p></main><dialog id="detail" class="detail"><div class="detailbar"><strong id="title"></strong><button id="before">修改前</button><button id="after">修改后</button><button id="compare">前后对照</button><button id="full">完整名称</button><button id="demo">试操作</button><button id="close" aria-label="关闭组件预览">关闭</button></div><p id="help" class="help"></p><div id="canvas" class="canvas"></div></dialog><script>
const cards=__CARDS__;let device='mobile',selected=null,view='after';const $=id=>document.getElementById(id);const guides={inventory:'库存：点击体检或补货记录中的长名称可查看全文。',rma:'售后：打开第一条申请，再点击商品名或客户名查看全文。',excel:'导入：打开 Excel 导入 → 粘贴表格 → 输入 sku,name 示例 → 生成导入预览。预检返回固定合成示例。',product:'商品：打开更多商品操作 → 商品详情。短名称直接显示；实际超出两行时可展开。',batch:'批次：打开「查看明细」，在商品行点击超长名称。',remax:'REMAX：选择到货批次，再点击到货行的名称。此工作区不会提交实际到货。'};
function render(){ $('grid').replaceChildren();for(const c of cards){const article=document.createElement('article');article.className='card';const meta=document.createElement('div');meta.className='meta';const heading=document.createElement('h2');heading.textContent=c.title;const p=document.createElement('p');p.textContent=c.description;const metric=document.createElement('div');metric.className='metric';metric.textContent=c.metric;meta.append(heading,p,metric);const thumb=document.createElement('button');thumb.className='thumb'+(device==='desktop'?' desktop':'');thumb.setAttribute('aria-label','预览 '+c.title+' 修改后');const img=document.createElement('img');img.src=c.shots[device].after.path;img.alt=c.title+' 修改后';img.loading='lazy';thumb.append(img);thumb.onclick=()=>open(c,'after');const actions=document.createElement('div');actions.className='actions';const compare=document.createElement('button');compare.textContent=c.shots[device].before?'前后对照':'查看详情';compare.onclick=()=>open(c,c.shots[device].before?'compare':'after');const demo=document.createElement('button');demo.textContent='试操作';demo.onclick=()=>open(c,'demo');actions.append(compare,demo);article.append(meta,thumb,actions);$('grid').append(article);}}
function open(c,mode){selected=c;view=mode;draw();$('detail').showModal();}
function addImage(shot,caption,parent){const img=document.createElement('img');img.src=shot.path;img.alt=selected.title+' '+caption;parent.append(img);}
function draw(){const shots=selected.shots[device];$('title').textContent=selected.title+' · '+(device==='mobile'?'手机':'电脑');$('before').disabled=!shots.before;$('compare').disabled=!shots.before;$('full').hidden=!shots.full;$('full').textContent=selected.id==='excel'?'确认门禁示例':'完整名称';for(const mode of ['before','after','compare','full','demo'])$(mode).classList.toggle('active',view===mode);const canvas=$('canvas');canvas.replaceChildren();$('help').textContent=view==='demo'?(guides[selected.id]||'使用顶部入口和原页面控件试操作，以下为本地合成数据。'):selected.description;if(view==='demo'){const frame=document.createElement('iframe');frame.src=selected.workspace;frame.title=selected.title+' 交互工作区';frame.style.width=(device==='mobile'?390:1440)+'px';canvas.append(frame);}else if(view==='compare'){const pair=document.createElement('div');pair.className='compare';for(const [key,label] of [['before','修改前'],['after','修改后']]){const figure=document.createElement('figure');const caption=document.createElement('figcaption');caption.textContent=label;figure.append(caption);addImage(shots[key],label,figure);pair.append(figure);}canvas.append(pair);}else addImage(shots[view]||shots.after,view,canvas);}
for(const mode of ['before','after','compare','full','demo'])$(mode).onclick=()=>{view=mode;draw();};$('close').onclick=()=>{$('detail').close();$('canvas').replaceChildren();};$('detail').addEventListener('close',()=>$('canvas').replaceChildren());for(const mode of ['mobile','desktop'])$(mode).onclick=()=>{device=mode;for(const key of ['mobile','desktop']){$(key).classList.toggle('active',key===mode);$(key).setAttribute('aria-pressed',String(key===mode));}render();};render();
</script></body></html>'''
(target / 'index.html').write_text(html.replace('__CARDS__', json.dumps(cards, ensure_ascii=False)))
evidence = target / 'evidence'
evidence.mkdir(exist_ok=True)
for source in [current/'annotated-results.json', current/'name-contexts.json', current/'modules/summary.json', current/'modules/independent-component-review.json']:
    shutil.copyfile(source, evidence/source.name)
print('Preview gallery saved:', target)
