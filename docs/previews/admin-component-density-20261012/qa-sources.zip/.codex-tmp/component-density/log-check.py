import json,subprocess,sys
from pathlib import Path
r=subprocess.run(['vercel','logs',sys.argv[1],'--no-follow','--level','error','--since','10m','--json','--scope','team_AOJDnrjov0QDLqpvMyhwA1yc'],capture_output=True,text=True)
rows=[]
for line in r.stdout.splitlines():
 try: item=json.loads(line)
 except:continue
 rows.append({'level':item.get('level'),'timestamp':item.get('timestamp'),'statusCode':item.get('statusCode')})
result={'deployment':sys.argv[1],'commandSucceeded':r.returncode==0,'observedErrorRecords':len(rows),'window':'10m','records':rows}
Path('outputs/admin-component-density-20261012/release/'+sys.argv[2]+'-errors.json').write_text(json.dumps(result,indent=2));print(json.dumps(result));assert r.returncode==0 and not rows
