import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {createRequire} from 'node:module';
import {catalogFixture} from '../preserve-style/catalog-fixture.mjs';
import {mockApi} from '../preserve-style/mock-api.mjs';
const {chromium}=createRequire('/Users/kyox215/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/package.json')('playwright');
const out='outputs/admin-component-density-20261012';
const long='名称很长且意大利文无空格abcdefghijklmnopqrstuvwxyz0123456789'.repeat(4);
const browser=await chromium.launch({channel:'chrome',headless:true});const results=[];
try {for(const width of [390,1440]) {
  const context=await browser.newContext({viewport:{width,height:width===390?844:900}});const page=await context.newPage();page.setDefaultTimeout(8000);
  const row={width,checks:{},errors:[],warnings:[],external:[],writes:[]};
  page.on('pageerror',e=>row.errors.push(e.message));page.on('console',m=>{if(m.type()==='error')row.errors.push(m.text());if(m.type()==='warning')row.warnings.push(m.text());});
  await context.route('**/*',async r=>{const req=r.request(),u=new URL(req.url());if(u.hostname!=='127.0.0.1'){row.external.push(u.origin);return r.abort();}if(!u.pathname.startsWith('/api/'))return r.continue();
    if(!['GET','HEAD'].includes(req.method())&&u.pathname!=='/api/admin/remax/import/preview'){row.writes.push(u.pathname);return r.abort();}
    const answer=catalogFixture(u.pathname,req.method(),null,u.searchParams)||await mockApi(u.pathname,req.method(),null,u.searchParams);
    if(u.pathname==='/api/admin/products')answer.json.data[0].name=long;
    if(u.pathname==='/api/admin/supplier-batches/FIX-BATCH'){answer.json.data.lines[0].name=long;answer.json.data.lines[0].product.name=long;}
    return r.fulfill(answer);
  });
  const shot=async name=>{assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),'document overflow '+name);await page.screenshot({path:`${out}/${name}-${width}-zh-CN.png`});};
  const expand=async(scope,key)=>{const title=scope.locator('[data-admin-expandable=truncated]').filter({visible:true}).first();await title.waitFor();const expected=await title.getByRole('button').textContent();await title.getByRole('button').click();const popup=page.getByRole('dialog',{name:'显示完整名称',exact:true});await popup.waitFor();const full=await popup.locator('p').textContent();assert.ok(full.startsWith('名称很长'));assert.equal(full,expected);await shot(key+'-name-full');await page.keyboard.press('Escape');await popup.waitFor({state:'hidden'});assert.ok(await scope.isVisible());row.checks[key+'FullNameAndEscape']=true;};
  await page.goto('http://127.0.0.1:3179/admin?panel=catalog&locale=zh-CN');await page.getByRole('button',{name:'更多商品操作: FIX-SKU-1',exact:true}).filter({visible:true}).click();await page.getByRole('menuitem',{name:'商品详情',exact:true}).click();let sheet=page.getByRole('dialog');await sheet.locator('h3 [data-admin-expandable]').waitFor();await sheet.locator('h3').first().scrollIntoViewIfNeeded();await shot('product-detail');await expand(sheet,'product-detail');await page.keyboard.press('Escape');await sheet.waitFor({state:'hidden'});
  await page.goto('http://127.0.0.1:3179/admin?panel=catalog&catalogView=batches&locale=zh-CN');await page.getByRole('button',{name:'查看明细',exact:true}).filter({visible:true}).first().click();sheet=page.getByRole('dialog');await sheet.locator('[data-admin-expandable=truncated]').filter({visible:true}).first().scrollIntoViewIfNeeded();await shot('batch-detail');await expand(sheet,'batch-detail');await page.keyboard.press('Escape');await sheet.waitFor({state:'hidden'});
  await page.goto('http://127.0.0.1:3179/admin?panel=remax&locale=zh-CN');const main=page.locator('main');await main.locator('button[role=combobox]').last().click();await page.getByRole('option').filter({hasText:'FIX-REMAX-BATCH'}).click();const arrival=main.locator('[id^=remax-received-]').first();await arrival.waitFor();await arrival.scrollIntoViewIfNeeded();await shot('remax-arrival');await expand(arrival.locator('xpath=../../..'),'remax-arrival');
  await main.locator('input[type=file]').setInputFiles({name:'fixture.csv',mimeType:'text/csv',buffer:Buffer.from('name,qty_ordered,cost_price,retail_price,b2b_price,publish\nFixture,10,5,15,10,true')});await main.getByRole('button',{name:/预检|检查|导入前|先检查/}).click();const preview=main.locator('table').filter({hasText:'FIX-SKU-1'}).first();await preview.scrollIntoViewIfNeeded();await shot('remax-import');await expand(preview,'remax-import');
  assert.deepEqual(row.errors,[]);assert.deepEqual(row.warnings,[]);assert.deepEqual(row.external,[]);assert.deepEqual(row.writes,[]);results.push(row);await fs.writeFile(out+'/name-contexts.json',JSON.stringify(results,null,2));console.log(JSON.stringify(row));await context.close();
}}finally{await browser.close();}
