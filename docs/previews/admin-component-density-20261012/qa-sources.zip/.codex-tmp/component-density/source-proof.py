import hashlib,json,subprocess,sys
from pathlib import Path
root=Path.cwd();out=root/'outputs/admin-component-density-20261012/release';out.mkdir(exist_ok=True)
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
subprocess.run(['git','diff','--exit-code','HEAD','--','src','public','.vercelignore','eslint.config.mjs','next.config.ts','package-lock.json','package.json','postcss.config.mjs','tsconfig.json','vercel.json','components.json'],check=True,capture_output=True)
tracked=subprocess.check_output(['git','ls-files','-z'],text=True).split('\0')
allowed=lambda p:p.startswith(('src/','public/')) or p in ['.vercelignore','eslint.config.mjs','next.config.ts','package-lock.json','package.json','postcss.config.mjs','tsconfig.json','vercel.json','components.json']
files={p:hashlib.sha1((root/p).read_bytes()).hexdigest() for p in tracked if p and allowed(p) and (root/p).is_file()}
(out/'source-manifest.json').write_text(json.dumps({'commit':commit,'files':files},indent=2))
if len(sys.argv)==1:print('Frozen runtime-source manifest:',len(files),commit);sys.exit()
dpl=sys.argv[1];r=subprocess.run(['vercel','api',f'/v6/deployments/{dpl}/files','--method','GET','--scope','team_AOJDnrjov0QDLqpvMyhwA1yc'],capture_output=True,text=True,check=True)
tree=json.loads(r.stdout);(out/'uploaded-file-tree.json').write_text(json.dumps(tree,indent=2));upload={}
def visit(items,prefix=''):
 if isinstance(items,dict):items=items.get('files',items.get('result',[]))
 for f in items:
  name=prefix+f['name']
  if f.get('children') is not None:visit(f['children'],name+'/')
  else:upload[name]=f.get('uid',f.get('id'))
visit(tree)
if upload and all(p.startswith('src/') for p in upload) and 'src/package.json' in upload:upload={p[4:]:v for p,v in upload.items()}
missing=[p for p in files if p not in upload];mismatch=[p for p in files if p in upload and upload[p]!=files[p]]
extras=[p for p in upload if p not in files];verified_extras=[p for p in extras if p in ['next-env.d.ts','components.json'] and (root/p).is_file() and hashlib.sha1((root/p).read_bytes()).hexdigest()==upload[p]]
unverified_extras=[p for p in extras if p not in verified_extras];sensitive=[p for p in upload if p.startswith(('.env','.codex','docs/','outputs/','supabase/','tests/','node_modules/')) or p.endswith(('.log','.pem'))]
result={'commit':commit,'deployment':dpl,'uploaded':len(upload),'manifestMatched':len(files)-len(missing)-len(mismatch),'missing':missing,'mismatch':mismatch,'verifiedExtras':verified_extras,'unverifiedExtras':unverified_extras,'sensitivePaths':sensitive}
(out/'source-verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result));assert not missing and not mismatch and not unverified_extras and not sensitive
